<svg wire:loading.remove.delay="1" wire:target="dispatchFormEvent('repeater::cloneItem', 'data.items', 'd27afe56-fee4-445c-98b4-e3788cef2a31')" class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z"/>
  <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h8a2 2 0 00-2-2H5z"/>
</svg><?php /**PATH C:\wamp64\www\sscom-app2\storage\framework\views/f7a9c81b8087b220555ae5f5a4a5f10c.blade.php ENDPATH**/ ?>