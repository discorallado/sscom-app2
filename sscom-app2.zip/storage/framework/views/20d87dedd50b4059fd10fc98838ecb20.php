<div class="filament-resource-relation-manager">
    <?php echo e(\Filament\Facades\Filament::renderHook('resource.relation-manager.start')); ?>


    <?php echo e($this->table); ?>


    <?php echo e(\Filament\Facades\Filament::renderHook('resource.relation-manager.end')); ?>

</div>
<?php /**PATH C:\wamp64\www\sscom-app2\resources\views/vendor/filament/resources/relation-manager.blade.php ENDPATH**/ ?>