<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['type', 'extraAttributes', 'icon', 'label', 'helperText']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['type', 'extraAttributes', 'icon', 'label', 'helperText']); ?>
<?php foreach (array_filter((['type', 'extraAttributes', 'icon', 'label', 'helperText']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $backgroundClass = match($type) {
        'primary' => 'bg-primary-500',
        'success' => 'bg-success-500',
        'warning' => 'bg-warning-500',
        'danger' => 'bg-danger-500',
        'secondary' => 'bg-gray-500',
    };

    $textColor = 'text-gray-50';

?>
<div <?php echo e($attributes
        ->merge($extraAttributes)
        ->class(
            [
                'filament-forms-text-input-component flex items-center space-x-2 rtl:space-x-reverse group p-5 rounded-lg',
                $backgroundClass,
                $textColor
            ]
        )); ?>

>
    <?php if($icon = $icon): ?>
        <div class="icon px-3 mr-2">
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $icon] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-10 h-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        </div>
    <?php endif; ?>
    <div class="alert-content">
        <?php if($label): ?>
            <div class="title">
                <h3 class="text-xl font-medium"><?php echo e($label); ?></h3>
            </div>
        <?php endif; ?>
        <div class="description font-light">
            <?php echo nl2br(htmlspecialchars($helperText)); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\sscom-app2\vendor\koalafacade\filament-alertbox\src\/../resources/views/components/base-alert-box.blade.php ENDPATH**/ ?>