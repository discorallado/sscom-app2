<svg wire:loading.remove.delay="1" wire:target="dispatchFormEvent('repeater::cloneItem', 'data.items', 'b55f61dc-c46d-4153-9ce8-6bbb7a0a4cfa')" class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z"/>
  <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h8a2 2 0 00-2-2H5z"/>
</svg><?php /**PATH C:\wamp64\www\sscom-app2\storage\framework\views/14ff57ebbc46280744adaf2add28e1c0.blade.php ENDPATH**/ ?>