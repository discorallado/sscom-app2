<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\wamp64\www\sscom-app2\resources\views/vendor/forms/components/grid.blade.php ENDPATH**/ ?>