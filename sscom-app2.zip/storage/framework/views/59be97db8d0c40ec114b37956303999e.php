<svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-linejoin="round" d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/>
</svg><?php /**PATH C:\wamp64\www\sscom-app2\storage\framework\views/b3d839df5c8d6eae26a6d6cf5af2c9fa.blade.php ENDPATH**/ ?>