import Alpine from 'alpinejs'
import '../../vendor/alperenersoy/filament-export/resources/js/filament-export.js';


window.Alpine = Alpine

Alpine.start()
