<div {{ $attributes }}>
    {{ $getChildComponentContainer() }}
</div>
