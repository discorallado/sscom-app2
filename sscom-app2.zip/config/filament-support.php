<?php

return [

    'modal' => [
        'is_closed_by_clicking_away' => true,
    ],

];
