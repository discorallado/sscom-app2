<?php

return [

    'cache-path' => storage_path('framework/cache'),

    'cache-prefix' => 'squire',

];
