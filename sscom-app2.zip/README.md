# erp v2
 ERP para cliente, diseñado para sus necesidades.
 Babasado en **Laravel 10** y **Filament TALL kit**
